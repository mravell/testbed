const Input = Formio.Components.components.input;
import editForm from './Map.form';

export default class MapComponent extends Input {

	static schema(...extend) {
		return Input.schema({
			type: 'map',
			label: 'Map',
			height: '300px',
			tableView: false,
			key: 'map'
		}, ...extend);
	}

	static get builderInfo() {
		return {
			title: 'Map',
			group: 'data',
			icon: 'globe',
			weight: 0,
			documentation: '/userguide/#hidden',
			schema: MapComponent.schema()
		};
	}

	get defaultSchema() {
		return MapComponent.schema();
	}

	static get editForm() {
		return editForm;
	}

	render(content) {
		return super.render('<div id="mapid" style="width:100%;height:300px;"></div>');
	}

	attach(element) {

		map.setView([51.505, -0.09], 13);

		L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
			attribution: 'Need to add attribution',
			maxZoom: 18,
			id: 'mapbox/streets-v11',
			tileSize: 512,
			zoomOffset: -1,
			accessToken: 'pk.eyJ1IjoibXJhdmVsbCIsImEiOiJja3VtNHhzaXMyNjB6MnJ0NHdwamI1ZzZxIn0.m1ZpowwdRpEtMPKNQYaWWA'
		}).addTo(map);

		return super.attach(element);
	}

	static map() {
		return L.map('mapid');
	};

}