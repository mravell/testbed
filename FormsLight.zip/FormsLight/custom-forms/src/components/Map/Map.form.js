const hidden = Formio.Components._components.hidden;
import MapEditDisplay from './editForm/Map.edit.display';
import MapEditData from './editForm/Map.edit.data';

export default function(...extend) {
  return hidden.editForm([
    {
      key: 'display',
      components: MapEditDisplay
    },
    {
      key: 'data',
      components: MapEditData
    },
    {
      key: 'validation',
      ignore: true
    },
    {
      key: 'conditional',
      ignore: true
    },
  ], ...extend);
}
