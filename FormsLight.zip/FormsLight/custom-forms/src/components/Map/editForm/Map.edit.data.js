export default [
  {
    key: 'persistent',
    ignore: true
  },
  {
    key: 'protexted',
    ignore: true
  },
  {
    key: 'multiple',
    ignore: true
  },
  {
    key: 'clearOnHide',
    ignore: true
  },
  {
    key: 'allowCalculateOverride',
    ignore: true
  }
];
