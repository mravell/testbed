const HiddenComponent = Formio.Components.components.hidden;
import editForm from './Object.form';

export default class Object extends HiddenComponent {
  static schema(...extend) {
    return HiddenComponent.schema({
      type: 'object',
      tableView: false,
      inputType: 'hidden',
      label: 'createObject',
      key: 'object'
    }, ...extend);
  }

  static get builderInfo() {
    return {
      title: 'SAP Object',
      group: 'advanced',
      icon: 'envelope',
      weight: 180,
      documentation: '/userguide/#hidden',
      schema: Object.schema()
    };
  }

  get defaultSchema() {
    return Object.schema();
  }

  static get editForm() {
		return editForm;
	}


}
