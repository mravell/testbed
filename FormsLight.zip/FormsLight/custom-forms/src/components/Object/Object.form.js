const hidden = Formio.Components._components.hidden;
import HiddenEditDisplay from './editForm/Object.edit.display';
import HiddenEditData from './editForm/Object.edit.data';

export default function(...extend) {
  return hidden.editForm([
    {
      key: 'display',
      components: HiddenEditDisplay
    },
    {
      key: 'data',
      components: HiddenEditData
    },
    {
      key: 'validation',
      ignore: true
    },
    {
      key: 'conditional',
      ignore: true
    },
    {
      key: 'layout',
      ignore: true
    },
    {
      key: 'addons',
      ignore: true
    },
  ], ...extend);
}
