export default [
  {
    type: "select",
    label: "Object Type",
    key: "objectType",
    weight: 0,
    placeholder: "Object Type",
    tooltip: "Select the object type for creation.",
    input: true,
    dataSrc: "custom",
    data: {
      custom: function custom(context) {
        // Hide preview panel in Object Component
        var previewPanel = document.getElementsByClassName("card panel preview-panel")[0];
        previewPanel.classList.add("hide-preview");

        // Maximize the column for edit in Object Component
        var colElements = document.getElementsByClassName("col col-sm-6");
        for (var i = 0; i < colElements.length; i++) {
          var columnEditComp = colElements[i];
          columnEditComp.classList.add("edit-col-width");
        }

        var values = [];
        var oModel = sap.ui.getCore().getModel("userInfo");
        var oController = oModel.getData().formCreateController;

        // Bind dropdown to model to allow data retrieval whenever model is updated
        var fieldModel = oController.getView().getModel("objectType").getData();
        if (fieldModel) {
          for (var field of fieldModel) {
            if (field.CanView === true || field.CanView === "true") {
              values.push({
                label: field.ObjectType,
                value: field.CreateModel,
              });
            }
          }
        }

        return values;
      },
    },
    validate: {
      required: true,
    },
  },
  {
    label: "If multiple Measurement Points found",
    widget: "choicesjs",
    tableView: true,
    defaultValue: "createMultipleMD",
    data: {
        values: [
            {
                label: "Create multiple Measurement Documents",
                value: "createMultipleMD"
            },
            {
                label: "Throw error",
                value: "throwError"
            }
        ]
    },
    key: "createMDCondition",
    conditional: {
      json: {
        "==": [{ var: "data.objectType.value" }, "MEASUREMENTDOCCREATE"],
      },
    },
    type: "select",
    input: true
  },
  {
    label: "Context Configuration",
    reorder: false,
    addAnotherPosition: "bottom",
    layoutFixed: false,
    enableRowGroups: false,
    initEmpty: false,
    tableView: false,
    width: 10,
    defaultValue: [
      {
        mode: "static",
        objectAttribute: "",
      },
    ],
    key: "dataGrid",
    weight: 10,
    type: "datagrid",
    input: true,
    components: [
      {
        label: "Object Attribute",
        widget: "choicesjs",
        tableView: true,
        dataSrc: "custom",
        data: {
          custom: function custom(context) {
            var values = [];
            var oModel = sap.ui.getCore().getModel("userInfo");
            var oController = oModel.getData().formCreateController;
            var selectedObject = context.data.objectType.value;
        
            // Bind dropdown to model to allow data retrieval whenever model is updated
            var fieldModel = oController.getView().getModel("objectCreateField").getData()[selectedObject];		
            if (fieldModel) {
              for (var field of fieldModel) {
                values.push({
                  label: field.Name,
                  value: field.SAPUpdateTable + "/" + field.SAPUpdateField,
                });
              }
            }
    
            return values;
          },
        },
        key: "objectAttribute",
        type: "select",
        input: true,
        validate: {
          required: true,
        }
      },
      {
        type: "radio",
        input: true,
        key: "mode",
        label: "Mode",
        inline: false,
        tableView: false,
        defaultValue: "static",
        values: [
          { label: "Static", value: "static" },
          { label: "Dynamic", value: "dynamic" },
        ],
      },
      {
        key: "fieldSet",
        type: "fieldSet",
        label: "Field Set",
        input: false,
        tableView: false,
        components: [
          {
            label: "Static Value",
            hideLabel: true,
            tableView: true,
            datasource: "static",
            key: "static",
            customConditional: "var oModel = sap.ui.getCore().getModel(\"userInfo\");\r\nvar oController = oModel.getData().formCreateController;\r\nif (row.mode === \"static\") {\r\n  if (row.objectAttribute.value) {\r\n    var sObjAttVal = row.objectAttribute.value;\r\n    var sModelName = sObjAttVal.split(\"/\")[1];\r\n    var dropdownModel = oController.getView().getModel(sModelName);\r\n    if (dropdownModel) {\r\n      show = false;\r\n    } else {\r\n      show = true;\r\n    }\r\n  } else {\r\n    show = true;\r\n  }\r\n} else {\r\n  show = false;\r\n}",
            type: "textfield",
            input: true,
            validate: {
              required: true,
            }
          },
          {
            label: "Static Dropdown",
            widget: "choicesjs",
            hideLabel: true,
            tableView: true,
            key: "staticDropdown",
            customConditional: "var oModel = sap.ui.getCore().getModel(\"userInfo\");\r\nvar oController = oModel.getData().formCreateController;\r\nif (row.objectAttribute.value) {\r\n   var sObjAttVal = row.objectAttribute.value;\r\n   var sModelName = sObjAttVal.split(\"/\")[1];\r\n   var dropdownModel = oController.getView().getModel(sModelName);\r\n   if (row.mode === \"static\" && dropdownModel ) {\r\n      show = true\r\n   } else {\r\n      show = false;\r\n   }\r\n} else {\r\n   show = false;\r\n}",
            type: "select",
            input: true,
            dataSrc: "custom",
            data: {
              custom: function custom(context) {
                var values = [];
                var oModel = sap.ui.getCore().getModel("userInfo");
                var oController = oModel.getData().formCreateController;
                var sObjAttVal = context.data.dataGrid[context.rowIndex].objectAttribute.value;
                if (sObjAttVal) {
                  var sModelName = sObjAttVal.split("/")[1];
                  // Bind dropdown to model to allow data retrieval whenever model is updated
                  var dropdownModel = oController.getView().getModel(sModelName);

                  if (dropdownModel) {
                    var dropdownList = dropdownModel.getData();
                    var keyColumn = dropdownList.fieldData.columnDetails.keyColumn;
                    var valuesColumn = dropdownList.fieldData.columnDetails.valuesColumn;
                    for (var item of dropdownList.rows) {
                      values.push({
                        label: item[keyColumn] + " - " + item[valuesColumn],
                        value: item[keyColumn],
                      });
                    }
                  }
                }
                return values;
              },
            },
            validate: {
              required: true,
            }
          },
          {
            label: "Dynamic Field",
            widget: "choicesjs",
            hideLabel: true,
            tableView: true,
            key: "dynamic",
            conditional: {
              show: true,
              when: "dataGrid.mode",
              eq: "dynamic",
            },
            type: "select",
            input: true,
            dataSrc: "custom",
            data: {
              custom: function custom(context) {
                // Find all the components of the current form
                var values = [];
                let oModel = sap.ui.getCore().getModel("userInfo");
                if (oModel.getData().formSchema) {
                  // Flatten all components to get all nested components
                  const schema = Formio.Utils.flattenComponents(
                    oModel.getData().formSchema.components
                  );
                  for (var element in schema) {
                    var comp = schema[element];
                    // Only show the other fields in the form. Not this one as we don't want a circular reference.
                    if (context.data.key != comp.key) {
                      values.push({
                        label: comp.key + " - " + comp.label,
                        value: comp.key,
                      });
                    }
                  }
                }
                return values;
              },
            },
            validate: {
              required: true,
            }
          },
        ],
      },
    ],
  },
  {
    label: "Operation Configuration",
    reorder: false,
    addAnotherPosition: "bottom",
    layoutFixed: false,
    enableRowGroups: false,
    initEmpty: false,
    tableView: false,
    width: 100,
    defaultValue: [
      {
        operMode: "static",
        operObjectAttribute: "",
      },
    ],
    key: "operDataGrid",
    weight: 20,
    customConditional: "if (data.objectType.value === \"WORKORDERCREATE\") {\n  show = true;\n} else {\n  show = false;\n}",
    type: "datagrid",
    input: true,
    components: [
      {
        label: "Object Attribute",
        widget: "choicesjs",
        tableView: true,
        dataSrc: "custom",
        data: {
          custom: function custom(context) {
            var values = [];
            var oModel = sap.ui.getCore().getModel("userInfo");
            var oController = oModel.getData().formCreateController;
        
            // Bind dropdown to model to allow data retrieval whenever model is updated
            var fieldModel = oController.getView().getModel("objectCreateField").getData().OPERATIONSCREATE;		
            if (fieldModel) {
              for (var field of fieldModel) {
                values.push({
                  label: field.Name,
                  value: field.SAPUpdateTable + "/" + field.SAPUpdateField,
                });
              }
            }
    
            return values;
          },
        },
        key: "operObjectAttribute",
        type: "select",
        input: true,
        validate: {
          required: true,
        }
      },
      {
        type: "radio",
        input: true,
        key: "operMode",
        label: "Mode",
        inline: false,
        tableView: false,
        defaultValue: "static",
        values: [
          { label: "Static", value: "static" },
          { label: "Dynamic", value: "dynamic" },
        ],
      },
      {
        key: "operFieldSet",
        type: "fieldset",
        label: "Field Set",
        input: false,
        tableView: false,
        components: [
          {
            label: "Static Value",
            hideLabel: true,
            tableView: true,
            datasource: "static",
            key: "operStatic",
            customConditional: "var oModel = sap.ui.getCore().getModel(\"userInfo\");\r\nvar oController = oModel.getData().formCreateController;\r\nif (row.operMode === \"static\") {\r\n  if (row.operObjectAttribute.value) {\r\n    var sObjAttVal = row.operObjectAttribute.value;\r\n    var sModelName = sObjAttVal.split(\"/\")[1];\r\n    var dropdownModel = oController.getView().getModel(sModelName);\r\n    if (dropdownModel) {\r\n      show = false;\r\n    } else {\r\n      show = true;\r\n    }\r\n  } else {\r\n    show = true;\r\n  }\r\n} else {\r\n  show = false;\r\n}",
            type: "textfield",
            input: true,
            validate: {
              required: true,
            }
          },
          {
            label: "Static Dropdown",
            widget: "choicesjs",
            hideLabel: true,
            tableView: true,
            key: "operStaticDropdown",
            customConditional: "if (Object.keys(row).length) {\r\n  var oModel = sap.ui.getCore().getModel(\"userInfo\");\r\n  var oController = oModel.getData().formCreateController;\r\n  if (row.operObjectAttribute.value) {\r\n     var sObjAttVal = row.operObjectAttribute.value;\r\n     var sModelName = sObjAttVal.split(\"/\")[1];\r\n     var dropdownModel = oController.getView().getModel(sModelName);\r\n     if (row.operMode === \"static\" && dropdownModel ) {\r\n        show = true\r\n     } else {\r\n        show = false;\r\n     }\r\n  } else {\r\n     show = false;\r\n  }\r\n} else {\r\n  show = false;\r\n}",
            type: "select",
            input: true,
            dataSrc: "custom",
            data: {
              custom: function custom(context) {
                var values = [];
                var oModel = sap.ui.getCore().getModel("userInfo");
                var oController = oModel.getData().formCreateController;
                var sObjAttVal = context.data.operDataGrid[context.rowIndex].operObjectAttribute.value;
                if (sObjAttVal) {
                  var sModelName = sObjAttVal.split("/")[1];
                  // Bind dropdown to model to allow data retrieval whenever model is updated
                  var dropdownModel = oController.getView().getModel(sModelName);

                  if (dropdownModel) {
                    var dropdownList = dropdownModel.getData();
                    var keyColumn = dropdownList.fieldData.columnDetails.keyColumn;
                    var valuesColumn = dropdownList.fieldData.columnDetails.valuesColumn;
                    for (var item of dropdownList.rows) {
                      values.push({
                        label: item[keyColumn] + " - " + item[valuesColumn],
                        value: item[keyColumn],
                      });
                    }
                  }
                }

                return values;
              },
            },
            validate: {
              required: true,
            }
          },
          {
            label: "Dynamic Field",
            widget: "choicesjs",
            hideLabel: true,
            tableView: true,
            key: "operDynamic",
            conditional: {
              show: true,
              when: "operDataGrid.operMode",
              eq: "dynamic",
            },
            type: "select",
            input: true,
            dataSrc: "custom",
            data: {
              custom: function custom(context) {
                // Find all the components of the current form
                var values = [];
                let oModel = sap.ui.getCore().getModel("userInfo");
                if (oModel.getData().formSchema) {
                  // Flatten all components to get all nested components
                  const schema = Formio.Utils.flattenComponents(
                    oModel.getData().formSchema.components
                  );
                  for (var element in schema) {
                    var comp = schema[element];
                    // Only show the other fields in the form. Not this one as we don't want a circular reference.
                    if (context.data.key != comp.key) {
                      values.push({
                        label: comp.key + " - " + comp.label,
                        value: comp.key,
                      });
                    }
                  }
                }
                return values;
              },
            },
            validate: {
              required: true,
            }
          },
        ],
      },
    ],
  },
	{
		type: "checkbox",
		label: "Attach Form as PDF on object",
		tooltip: "Should the completed Form attach to this object during creation?",
		key: "attachForm",
		input: true
	},
  {
    key: "persistent",
    ignore: true,
  },
  {
    key: "protected",
    ignore: true,
  },
  {
    key: "encrypted",
    ignore: true,
  },
  {
    key: "dbIndex",
    ignore: true,
  },
  {
    key: "multiple",
    ignore: true,
  },
  {
    key: "clearOnHide",
    ignore: true,
  },
  {
    key: "allowCalculateOverride",
    ignore: true,
  },
  {
    key: "redrawOn",
    ignore: true,
  },
  {
    key: "calculateServer",
    ignore: true,
  },
];
