export default [
	{
		label: "Object creation based on",
		optionsLabelPosition: "right",
		inline: false,
		tableView: false,
		defaultValue: "withoutCondtion",
		values: [
			{
				label: "Without condtion",
				value: "withoutCondtion",
				shortcut: ""
			},
			{
				label: "Condition",
				value: "condition",
				shortcut: ""
			}
		],
		key: "objectCreationBasedOn",
		type: "radio",
		input: true
	},
	{
		label: "Field Datatype",
		widget: "choicesjs",
		tableView: true,
		data: {
		  values: [
			{
			  label: "Integer",
			  value: "integer"
			},
			{
			  label: "String",
			  value: "string"
			}
		  ]
		},
		key: "fieldDatatype",
		type: "select",
		tooltip: "Datatype of selected comparison field",
		input: true,
		conditional: {
			json: {
			  "==": [{ var: "data.objectCreationBasedOn" }, "condition"],
			},
		},
		validate: {
			required: true,
		}
	},
	{
		label: "Conditional Field",
		widget: "choicesjs",
		tableView: true,
		key: "conditionalField",
		type: "select",
		tooltip: "Create object based on value of this field.",
		input: true,
		dataSrc: "custom",
		data: {
			custom: function custom(context) {
			// Find all the components of the current form
			var values = [];
			let oModel = sap.ui.getCore().getModel("userInfo");
			if (oModel.getData().formSchema) {
				// Flatten all components to get all nested components
				const schema = Formio.Utils.flattenComponents(
				oModel.getData().formSchema.components
				);
				for (var element in schema) {
				var comp = schema[element];
				// Only show the other fields in the form. Not this one as we don't want a circular reference.
				if (context.data.key != comp.key) {
					values.push({
						label: comp.key + " - " + comp.label,
						value: comp.key,
						});
					}
				}
			}
			return values;
			},
		},
		conditional: {
			json: {
			  "==": [{ var: "data.objectCreationBasedOn" }, "condition"],
			},
		},
		validate: {
			required: true,
		}
	},
	{
		label: "Comparison Operators",
		widget: "choicesjs",
		customClass: "is-flipped",
		tableView: true,
		data: {
		  values: [
			{
			  label: "Equals to",
			  value: "EQ"
			},
			{
			  label: "Greater than",
			  value: "GT"
			},
			{
			  label: "Greater than or equal to",
			  value: "GE"
			},
			{
			  label: "Less than",
			  value: "LT"
			},
			{
			  label: "Less than or equal to",
			  value: "LE"
			},
			{
				label: "Between",
				value: "BT"
			  }
		  ]
		},
		key: "intComparisonOperators",
		type: "select",
		tooltip: "Operator used to compare field's value and predefined value.",
		conditional: {
			json: {
				"and" : [{
					"==": [{ var: "data.objectCreationBasedOn" }, "condition"],
					"==": [{ var: "data.fieldDatatype" }, "integer"],
				}],
			},
		},
		validate: {
			required: true,
		}
	},
	{
		label: "Comparison Operators",
		widget: "choicesjs",
		tableView: true,
		data: {
		  values: [
			{
			  label: "Equals to",
			  value: "EQ"
			},
			{
			  label: "Not equal to",
			  value: "NE"
			},
		  ]
		},
		key: "stringComparisonOperators",
		type: "select",
		tooltip: "Operator used to compare field's value and predefined value.",
		conditional: {
			json: {
				"and" : [{
					"==": [{ var: "data.objectCreationBasedOn" }, "condition"],
					"==": [{ var: "data.fieldDatatype" }, "string"],
				}],
			},
		},
		validate: {
			required: true,
		}
	},
	{
		label: "Comparison value(s)",
		tableView: true,
		datasource: "static",
		key: "comparisonValue",
		type: "textfield",
		tooltip: "Predefined comparison value used to for comparison with the selected Conditional Field.\nFor 'Between' operator, please a comma between the values, eg. 4,10",
		input: true,
		conditional: {
			json: {
			  "==": [{ var: "data.objectCreationBasedOn" }, "condition"],
			},
		},
		validate: {
			required: true,
		}
	},
	{
		key: 'labelPosition',
		ignore: true
	},
	{
		key: 'placeholder',
		ignore: true
	},
	{
		key: 'description',
		ignore: true
	},
	{
		key: 'tooltip',
		ignore: true
	},
	{
		key: 'hideLabel',
		ignore: true
	},
	{
		key: 'autofocus',
		ignore: true
	},
	{
		key: 'tabindex',
		ignore: true
	},
	{
		key: 'hidden',
		ignore: true
	},
	{
		key: 'tableView',
		ignore: true
	},
	{
		key: 'customClass',
		ignore: true
	},
	{
		key: 'modalEdit',
		ignore: true
	}


];
