import object from './Object/Object';

import CurrencyComponent from './context/currency/ContextCurrency';
import DateTimeComponent from './context/datetime/ContextDateTime';
import DayComponent from './context/day/ContextDay';
import EmailComponent from './context/email/ContextEmail';
import HiddenComponent from './context/hidden/ContextHidden';
import NumberComponent from './context/number/ContextNumber';
import PhoneNumberComponent from './context/phoneNumber/ContextPhoneNumber';
import TextAreaComponent from './context/textarea/ContextTextArea';
import TextFieldComponent from './context/textfield/ContextTextField';
import TimeComponent from './context/time/ContextTime';

import GeospatialComponent from './Geospatial/Geospatial';
import SelectComponent from './dropdown/select/DropdownSelect';

export default {
	object: object,

	currency: CurrencyComponent,
	datetime: DateTimeComponent,
	day: DayComponent,
	email: EmailComponent,
	hidden: HiddenComponent,
	number: NumberComponent,
	phoneNumber: PhoneNumberComponent,
	textarea: TextAreaComponent,
	textfield: TextFieldComponent,
	time: TimeComponent,

	geospatial: GeospatialComponent,
	select: SelectComponent
};
