export default [
  {
    type: "select",
    label: "Source",
    key: "source",
    weight: 9,
    placeholder: "Source",
    tooltip: "Select the source of dropdown list.",
    dataSrc: "values",
    input: true,
    defaultValue: "masterdata",
    data: {
      values: [
        { label: "Masterdata", value: "masterdata" },
        { label: "User edit", value: "userEdit" },
      ]
    },
    conditional: {
      json: {
        "==": [{ var: "data.dataSrc" }, "custom"],
      },
    },
  },
  {
    type: "select",
    label: "Search Term",
    key: "searchTerm",
    weight: 9,
    placeholder: "Search Term",
    tooltip: "Select the search term from masterdata.",
    dataSrc: "custom",
    input: true,
    data: {
      custom: function custom(context) {
        var values = [];
        var oModel = sap.ui.getCore().getModel("userInfo");
        var oController = oModel.getData().formCreateController;

        var dropdownList = oController.getView().getModel("masterdataList").getData();
        if (dropdownList) {
          for (var item of dropdownList) {
            values.push({
              label: item.label,
              value: item.value,
            });
          }
        }
      
        return values;
      },
    },
    validate: {
      required: true,
    },
    conditional: {
      json: {
        "==": [{ var: "data.source" }, "masterdata"],
      },
    },
  },
  {
    type: "checkbox",
    label: "Masterdata database",
    key: "masterdataDatabase",
    weight: 9,
    placeholder: "Table name",
    tooltip: "Select data from Masterdata database.",
    input: true,
    defaultValue: false,
    tableView: false,
    conditional: {
      json: {
        "==": [{ var: "data.source" }, "userEdit"],
      },
    },
  },
  {
    type: "textfield",
    label: "Table",
    key: "table",
    weight: 9,
    placeholder: "Table name",
    tooltip: "Please enter the table name for search.",
    input: true,
    validate: {
      required: true,
    },
    conditional: {
      json: {
        "==": [{ var: "data.source" }, "userEdit"],
      },
    },
  },
  {
    type: "textfield",
    label: "Column",
    key: "column",
    weight: 9,
    placeholder: "Column",
    tooltip: "Please enter the column for search.",
    input: true,
    validate: {
      required: true,
    },
    conditional: {
      json: {
        "==": [{ var: "data.source" }, "userEdit"],
      },
    },
  },
  {
    type: "textfield",
    label: "Search Terms",
    key: "searchTerms",
    weight: 9,
    placeholder: "Search Terms",
    tooltip: "Please enter the search terms.",
    input: true,
    validate: {
      required: true,
    },
    conditional: {
      json: {
        "==": [{ var: "data.source" }, "userEdit"],
      },
    },
  },
  {
    type: "textfield",
    label: "Key Column",
    key: "keyColumn",
    weight: 9,
    placeholder: "Key Column",
    tooltip: "Please enter the key column.",
    input: true,
    validate: {
      required: true,
    },
    conditional: {
      json: {
        "==": [{ var: "data.source" }, "userEdit"],
      },
    },
  },
  {
    type: "textfield",
    label: "Value Column",
    key: "valueColumn",
    weight: 9,
    placeholder: "Value Column",
    tooltip: "Please enter the value column.",
    input: true,
    conditional: {
      json: {
        "==": [{ var: "data.source" }, "userEdit"],
      },
    },
  },
  {
    type: "textfield",
    label: "Additional Column",
    key: "additionalColumn",
    weight: 9,
    placeholder: "Additional Column",
    tooltip: "Please enter the additional column.",
    input: true,
    conditional: {
      json: {
        "==": [{ var: "data.source" }, "userEdit"],
      },
    },
  }
];
