import DataDropdown from '../Edit.data';

const comp = Formio.Components.components.select;

export default class DropdownSelect extends comp {

  static get editForm() { 
    return function (...extend) {
      return comp.editForm([
      {
        label: 'Data',
        key: 'data',
        weight: 20,
        components: DataDropdown
      }
    ], ...extend); }
  }

  static get builderInfo() {
    return {
      title: 'Select',
      group: 'basic',
      icon: 'th-list',
      weight: 70,
      documentation: '/userguide/#select',
      schema: comp.schema()
    };
  }

}
