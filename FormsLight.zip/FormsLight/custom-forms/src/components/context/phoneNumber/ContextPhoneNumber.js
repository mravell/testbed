import DataContext from '../Edit.data';

const comp = Formio.Components.components.phoneNumber;

export default class ContextPhoneNumber extends comp {

  static get editForm() { 
    return function (...extend) {
      return comp.editForm([
      {
        label: 'Data',
        key: 'data',
        weight: 20,
        components: DataContext
      }
    ], ...extend); }
  }

  static get builderInfo() {
    return {
      title: 'Phone Number',
      group: 'advanced',
      icon: 'phone-square',
      weight: 30,
      documentation: '/userguide/#phonenumber',
      schema: comp.schema()
    };
  }

  // get defaultSchema() {
  //   return ContextPhoneNumber.schema();
  // }

}
