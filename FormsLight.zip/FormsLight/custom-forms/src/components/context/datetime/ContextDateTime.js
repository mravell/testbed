import DataContext from '../Edit.data';

const comp = Formio.Components.components.datetime;

export default class ContextDateTime extends comp {

  static get editForm() { 
    return function (...extend) {
      return comp.editForm([
      {
        label: 'Data',
        key: 'data',
        weight: 20,
        components: DataContext
      }
    ], ...extend); }
  }

  static get builderInfo() {
    return {
      title: 'Date / Time',
      group: 'advanced',
      icon: 'calendar',
      documentation: '/userguide/#datetime',
      weight: 40,
      schema: comp.schema()
    };
  }

}
