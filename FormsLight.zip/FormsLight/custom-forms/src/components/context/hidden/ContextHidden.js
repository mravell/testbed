import DataContext from '../Edit.data';

const comp = Formio.Components.components.hidden;

export default class ContextHidden extends comp {

  static get editForm() { 
    return function (...extend) {
      return comp.editForm([
      {
        label: 'Data',
        key: 'data',
        weight: 20,
        components: DataContext
      }
    ], ...extend); }
  }

  static get builderInfo() {
    return {
      title: 'Hidden',
      group: 'data',
      icon: 'user-secret',
      weight: 0,
      documentation: '/userguide/#hidden',
      schema: comp.schema()
    };
  }

}
