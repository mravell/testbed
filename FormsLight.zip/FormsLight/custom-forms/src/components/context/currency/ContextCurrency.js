import DataContext from '../Edit.data';

const comp = Formio.Components.components.currency;

export default class ContextCurrency extends comp {

  static get editForm() { 
    return function (...extend) {
      return comp.editForm([
      {
        label: 'Data',
        key: 'data',
        weight: 20,
        components: DataContext
      }
    ], ...extend); }
  }

  static get builderInfo() {
    return {
      title: 'Currency',
      group: 'advanced',
      icon: 'usd',
      documentation: '/userguide/#currency',
      weight: 70,
      schema: comp.schema()
    };
  }

}
