import DataContext from '../Edit.data';

const comp = Formio.Components.components.textfield;

export default class ContextTextField extends comp {

  static get editForm() { 
    return function (...extend) {
      return comp.editForm([
      {
        label: 'Data',
        key: 'data',
        weight: 20,
        components: DataContext
      }
    ], ...extend); }
  }

  static get builderInfo() {
    return {
      title: 'Text Field',
      group: 'basic',
      icon: 'terminal',
      weight: 0,
      documentation: '/userguide/#textfield',
      schema: comp.schema()
    };
  }

  static get dataContext () {
    return DataContext;
  }
}