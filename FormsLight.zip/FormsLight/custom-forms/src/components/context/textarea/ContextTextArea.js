import DataContext from '../Edit.data';

const comp = Formio.Components.components.textarea;

export default class ContextTextArea extends comp {

  static get editForm() { 
    return function (...extend) {
      return comp.editForm([
      {
        label: 'Data',
        key: 'data',
        weight: 20,
        components: DataContext
      }
    ], ...extend); }
  }

  static get builderInfo() {
    return {
      title: 'Text Area',
      group: 'basic',
      icon: 'font',
      weight: 20,
      documentation: '/userguide/#textarea',
      schema: comp.schema()
    };
  }

}
