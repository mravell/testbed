export default [
  {
    key: "persistent",
    ignore: true,
  },
  {
    weight: 2,
    type: "radio",
    input: true,
    key: "datasource",
    label: "Source",
    tooltip:
      "Choose how to assign data to this field. Either from the SAP context, User Details or as a static entry.",
    defaultValue: "static",
    values: [
      { label: "Static", value: "static" },
      { label: "Context", value: "context" },
      { label: "User Profile Parameter", value: "userProfile" },
    ],
  },
  {
    weight: 3,
    type: "textfield",
    key: "userProfileParam",
    label: "User Profile Parameter",
    tooltip:
    "Enter the User Profile Parameter that you want to source for this field.",
    input: true,
    conditional: {
      json: {
        "==": [{ var: "data.datasource" }, "userProfile"],
      },
    },
  },
  {
    weight: 4,
    type: "select",
    input: true,
    key: "object",
    label: "Context Object",
    tooltip:
      "Select the SAP object in context that you want an attribute from for this field.",
    dataSrc: "custom",
    data: {
      custom: function custom(context) {
        var values = [];
        var oModel = sap.ui.getCore().getModel("userInfo");
        var oController = oModel.getData().formCreateController;

        var dropdownList = oController.getView().getModel("contextObject").getData();
        if (dropdownList) {
          for (var item of dropdownList) {
            if (item.CanView === true || item.CanView === "true") {
              values.push({
                label: item.ObjectName,
                value: item.TableName,
              });
            }
          }
        }
      
        return values;
      },
    },
    validate: {
      required: true,
    },
    conditional: {
      json: {
        "==": [{ var: "data.datasource" }, "context"],
      },
    },
  },
  {
    weight: 5,
    label: "Based on",
    optionsLabelPosition: "right",
    inline: true,
    tableView: false,
    defaultValue: "assignedObject",
    values: [
      {
        label: "Assigned object",
        value: "assignedObject",
        shortcut: ""
      },
      {
        label: "Dynamic field",
        value: "dynamicField",
        shortcut: ""
      }
    ],
    key: "basedOn",
    type: "radio",
    labelWidth: 10,
    input: true,
    conditional: {
      json: {
        "==": [{ var: "data.datasource" }, "context"],
      },
    }
  },
  {
    weight: 6,
    label: "Dynamic field",
    widget: "choicesjs",
    tableView: true,
    key: "dynamicField",
    conditional: {
      show: true,
      when: "basedOn",
      eq: "dynamicField"
    },
    type: "select",
    input: true,
    dataSrc: "custom",
    data: {
      custom: function custom(context) {
        // Find all the components of the current form
        var values = [];
        let oModel = sap.ui.getCore().getModel("userInfo");
        if (oModel.getData().formSchema) {
          // Flatten all components to get all nested components
          const schema = Formio.Utils.flattenComponents(
            oModel.getData().formSchema.components
          );
          for (var element in schema) {
            var comp = schema[element];
            // Only show the other fields in the form. Not this one as we don't want a circular reference.
            if (context.data.key != comp.key) {
              values.push({
                label: comp.key + " - " + comp.label,
                value: comp.key,
              });
              // make sure that the conditional field for current context component is not empty
              if ((comp.datasource === "context" && (comp.objectLevel == undefined || comp.objectLevel.value === "headerLevel")) ||
                  (comp.datasource === "static" && comp.defaultValue)) {
                values.push({
                    label: comp.key + " - " + comp.label,
                    value: comp.key,
                });
            }
            }
          }
        }
        return values;
      },
    },
    validate: {
      required: true,
    }
  },
  {
    weight: 7,
    type: "select",
    input: true,
    key: "objectLevel",
    label: "Object level",
    tooltip:
      "Select the level from selected object.",
    dataSrc: "custom",
    data: {
      custom: function custom(context) {
        var values = [];
        values.push({
          label: "Header Level",
          value: "headerLevel",
        });
        var oModel = sap.ui.getCore().getModel("userInfo");
        var oController = oModel.getData().formCreateController;
        var sModelName = context.data.object.value + "-ObjectLevel";

        var dropdownModel = oController.getView().getModel(sModelName);
        if (dropdownModel) {
          var dropdownList = dropdownModel.getData();
          if (dropdownList) {
            for (var item of dropdownList) {
              if (item.CanView === true || item.CanView === "true") {
                values.push({
                  label: item.ObjectName,
                  value: item.TableName,
                });
              }
            }
          }
        }
      
        return values;
      },
    },
    defaultValue: {
      "label": "Header Level",
      "value": "headerLevel"
    },
    validate: {
      required: true,
    },
    conditional: {
      json: {
        "==": [{ var: "data.datasource" }, "context"],
      },
    },
  },
  {
    weight: 8,
    type: "select",
    input: true,
    key: "objectAttributes",
    label: "Object Attribute",
    tooltip:
      "Select the attribute from selected object that will be populated into this field.",
    dataSrc: "custom",
    data: {
      custom: function custom(context) {
        var values = [];
        var oModel = sap.ui.getCore().getModel("userInfo");
        var oController = oModel.getData().formCreateController;
        var sObjectLevel = context.data.objectLevel;
        if (sObjectLevel.value === "headerLevel") {
          var sModelName = context.data.object.value;
        } else {
          var sModelName = context.data.object.value + "-" + sObjectLevel.value;
        }

        if (sModelName) {
          var dropdownModel = oController.getView().getModel(sModelName);
          if (dropdownModel) {
            var dropdownList = dropdownModel.getData();
            if (dropdownList) {
              for (var item of dropdownList) {
                values.push({
                  label: oController.getResourceText(item.Name),
                  value: item.SAPUpdateField,
                });
              }
            }
          }
        }
      
        return values;
      },
    },
    validate: {
      required: true,
    },
    conditional: {
      json: {
        "==": [{ var: "data.datasource" }, "context"],
      },
    },
  },
  {
    weight: 9,
    type: "checkbox",
    label: "Prompt User",
    tooltip:
      "Should the form prompt the user to select the SAP object if it is not already in context?",
    key: "prompt",
    input: true,
    conditional: {
      json: {
        "==": [{ var: "data.datasource" }, "context"],
      },
    },
  },
  {
    weight: 10,
    type: "textfield",
    label: "Default Value",
    key: "defaultValue",
    placeholder: "Default Value",
    tooltip:
      "The will be the value for this field, before user interaction. Having a default value will override the placeholder text.",
    input: true,
    conditional: {
      json: {
        "==": [{ var: "data.datasource" }, "static"],
      },
    },
  }
];
