import DataContext from '../Edit.data';

const comp = Formio.Components.components.day;

export default class ContextDay extends comp {

  static get editForm() { 
    return function (...extend) {
      return comp.editForm([
      {
        label: 'Data',
        key: 'data',
        weight: 20,
        components: DataContext
      }
    ], ...extend); }
  }

  static get builderInfo() {
    return {
      title: 'Day',
      group: 'advanced',
      icon: 'calendar',
      documentation: '/userguide/#day',
      weight: 50,
      schema: comp.schema()
    };
  }

}
