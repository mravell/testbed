import DataContext from '../Edit.data';

const comp = Formio.Components.components.time;

export default class ContextTime extends comp {

  static get editForm() { 
    return function (...extend) {
      return comp.editForm([
      {
        label: 'Data',
        key: 'data',
        weight: 20,
        components: DataContext
      }
    ], ...extend); }
  }

  static get builderInfo() {
    return {
      title: 'Time',
      icon: 'clock-o',
      group: 'advanced',
      documentation: '/userguide/#time',
      weight: 55,
      schema: comp.schema(),
    };
  }

}
