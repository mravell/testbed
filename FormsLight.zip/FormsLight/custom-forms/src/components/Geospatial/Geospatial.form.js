const hidden = Formio.Components._components.hidden;
import EditDisplay from './editForm/Geospatial.edit.display';
import EditData from './editForm/Geospatial.edit.data';

export default function(...extend) {
  return hidden.editForm([
    {
      key: 'display',
      components: EditDisplay
    },
    {
      key: 'data',
      components: EditData
    },
    {
      key: 'validation',
      ignore: true
    },
    {
      key: 'conditional',
      ignore: true
    },
    {
      key: 'addons',
      ignore: true
    },
  ], ...extend);
}
