export default [
	{
		key: 'placeholder',
		ignore: true
	},
	{
		key: 'description',
		ignore: true
	},
	{
		key: 'autofocus',
		ignore: true
	},
	{
		key: 'tabindex',
		ignore: true
	},
	{
		key: 'tableView',
		ignore: true
	},
	{
		key: 'modalEdit',
		ignore: true
	}
];
