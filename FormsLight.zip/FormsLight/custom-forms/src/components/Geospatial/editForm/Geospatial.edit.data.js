export default [
  {
    key: 'defaultValue',
    ignore: true
  },
  {
    key: 'persistent',
    ignore: true
  },
  {
    key: 'protexted',
    ignore: true
  },
  {
    key: 'multiple',
    ignore: true
  },
  {
    key: 'clearOnHide',
    ignore: true
  },
  {
    key: 'allowCalculateOverride',
    ignore: true
  },
  {
    key: 'protected',
    ignore: true
  },
  {
    key: 'dbIndex',
    ignore: true
  },
  {
    key: 'encrypted',
    ignore: true
  },
  {
    key: 'calculateServer',
    ignore: true
  },
  
];
