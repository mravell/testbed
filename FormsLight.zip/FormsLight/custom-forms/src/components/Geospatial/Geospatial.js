const Input = Formio.Components.components.input;
import editForm from './Geospatial.form';

export default class GeospatialComponent extends Input {

	static schema(...extend) {
		return Input.schema({
			type: 'geospatial',
			label: 'Geospatial',
			tableView: false,
			key: 'geospatial'
		}, ...extend);
	}

	static get builderInfo() {
		return {
			title: 'Geospatial',
			group: 'advanced',
			icon: 'globe',
			weight: 200,
			schema: GeospatialComponent.schema()
		};
	}

	init() {
		super.init();

		this.currentWidth = 0;
		if (!this.component.width) {
			this.component.width = '100%';
		}
		if (!this.component.height) {
			this.component.height = '300px';
		}

		// Each instance of the component needs it's own id. Use the date in milliseconds as an easy unique one.
		this.component.mapid = Date.now().toString();
	}

	get defaultSchema() {
		return GeospatialComponent.schema();
	}

	static get editForm() {
		return editForm;
	}

	labelIsHidden() {
		return this.component.hideLabel;
	}
	
	attach(element) {

		this.loadRefs(element, { div: 'single' });
		const superAttach = super.attach(element);

		if (this.refs.div) {
			this.map = new MapComponent(this.refs.div, {
				minWidth: this.component.minWidth,
				maxWidth: this.component.maxWidth
			})
		}

		var map = L.map(this.component.mapid);
		map.locate({setView: true, maxZoom: 16});
		map.pm.addControls({ 
			position: 'topright', 
			drawCircle: false, 
			drawRectangle: false,
			drawCircleMarker: false,
			cutPolygon: false
		});

		L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
			attribution: '© <a href="https://www.mapbox.com/about/maps/">Mapbox</a> © <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> <strong><a href="https://www.mapbox.com/map-feedback/" target="_blank">Improve this map</a></strong>',
			tileSize: 512,
			maxZoom: 18,
			zoomOffset: -1,
			id: 'mapbox/streets-v11',
			accessToken: 'YOUR_MAPBOX_ACCESS_TOKEN'
		}).addTo(map);

		var marker;
		var layersOnMap = L.featureGroup();

		map.invalidateSize();

		map.on('pm:create', (e)=>{
			e.layer.addTo(layersOnMap); 
			this.setValue(layersOnMap.toGeoJSON());
		});

		map.on('pm:remove', (e)=>{
			e.layer.removeFrom(layersOnMap); 
			if (layersOnMap.getLayers().length == 0) {
				this.setValue("");
			} else {
				this.setValue(layersOnMap.toGeoJSON());
			}
		});

		map.on('locationfound', (e) => {
			var radius = e.accuracy / 2;
			L.marker(e.latlng).addTo(map);
		});

		return superAttach;
	}

	renderElement(value, index) {
		return this.renderTemplate('geospatial', {
			element: super.renderElement(value, index),
			required: _.get(this.component, 'validate.required', false),
		});
	}

}