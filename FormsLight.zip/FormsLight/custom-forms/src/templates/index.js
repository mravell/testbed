import bootstrap from './bootstrap';

export default {
  bootstrap,
};
