import form from './form.ejs';
import html from './html.ejs';

export default { form, html };
