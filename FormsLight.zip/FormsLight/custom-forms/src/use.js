import { Formio } from 'formiojs';
import FormioContrib from './index';
Formio.use(FormioContrib);
export default FormioContrib;
