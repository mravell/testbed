import components from './components';
import templates from './templates';

export default {
	components: components,
	templates: templates
};
